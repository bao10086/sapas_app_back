import filter
import split_wav
import mel
import finger_predict
#待传入参数
raw_wav=""
user_phone=""
unfilter_path="./models/raw_wav/"+user_phone+"/*.wav"
filter_path="./models/raw_wav/"+user_phone+"/*_filtered.wav"
wav_path="./models/wav/"+user_phone+"/"
pic_dir="./models/pic/"+user_phone+"/"




filtered_wav=filter.filter_main(unfilter_path,filter_path)
split_wav_dirs=split_wav.split_wav(filtered_wav,wav_path)
#分类数目
img_dir=mel.mel_main(split_wav_dirs,pic_dir)
# finger_train.finger_train_main(user_phone)

