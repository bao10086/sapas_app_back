# 导入包
import torch
import torchvision.transforms as transforms
from PIL import Image
from finger_model import Finger_Model,finger_class


#待传入参数

# 导入图像
im = Image.open('data/test/4/20221023_114758.png').convert('RGB')
# 模型路径
model_path='./models/197880957/best.pth'
#类别
nclass=2
# 预测的类别名字
classes = ('3','4')









# 数据预处理
transform = transforms.Compose(
    [transforms.Resize((224, 224)), # 首先需resize成跟训练集图像一样的大小
     transforms.ToTensor(),
     transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])



im = transform(im)  # [C, H, W]
im = torch.unsqueeze(im, dim=0)  # 对数据增加一个新维度，因为tensor的参数是[batch, channel, height, width] 

# 实例化网络，加载训练好的模型参数
net = Finger_Model(n_class=nclass).eval()
net.load_state_dict(torch.load(model_path),False)


with torch.no_grad():
    
    outputs = net(im)
    #print(outputs)
    predict = torch.max(outputs, dim=1)[1].data.numpy()
    #可以加入log
    pred_softmax = torch.softmax(outputs, dim=1)
    print(pred_softmax)
print(classes[int(predict)])
