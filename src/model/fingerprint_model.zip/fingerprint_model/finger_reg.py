import filter
import split_wav
import mel
import finger_train
#待传入参数
raw_wav=""
user_phone=""

unfilter_path="C:/Users/18255/Desktop/flask/src/model/fingerprint_model/models/raw_wav/"+user_phone+"/*.wav"
filter_path="C:/Users/18255/Desktop/flask/src/model/fingerprint_model/models/raw_wav/"+user_phone+"/*_filtered.wav"
wav_path="C:/Users/18255/Desktop/flask/src/model/fingerprint_model/models/wav/"+user_phone+"/"
pic_dir="C:/Users/18255/Desktop/flask/src/model/fingerprint_model/models/pic/"+user_phone+"/"




filtered_wav=filter.filter_main(unfilter_path,filter_path)
split_wav_dirs=split_wav.split_wav(filtered_wav,wav_path)
#分类数目
img_dir=mel.mel_main(split_wav_dirs,pic_dir)
finger_train.finger_train_main(user_phone)

